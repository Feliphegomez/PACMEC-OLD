# Pacmec.ListwalletsExchangesRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**walletFrom** | **Number** |  | [optional] 
**walletTo** | **Number** |  | [optional] 
**amount** | **Number** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
