# Pacmec.ListMenus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListmenusRecords]**](ListmenusRecords.md) |  | [optional] 
