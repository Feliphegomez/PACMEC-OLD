# Pacmec.ListMemberships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListmembershipsRecords]**](ListmembershipsRecords.md) |  | [optional] 
