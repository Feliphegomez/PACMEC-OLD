# Pacmec.ReadAffiliates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**membership** | **Number** |  | [optional] 
**codeId** | **String** |  | [optional] 
**initialPayment** | **String** |  | [optional] 
**billingAmount** | **String** |  | [optional] 
**cycleNumber** | **Number** |  | [optional] 
**maxMembers** | **Number** |  | [optional] 
**cyclePeriod** | **String** |  | [optional] 
**expirationPeriod** | **String** |  | [optional] 
**status** | **String** |  | [optional] 
**startdate** | **Date** |  | [optional] 
**enddate** | **Date** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
