# Pacmec.ListWalletsExchanges

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListwalletsExchangesRecords]**](ListwalletsExchangesRecords.md) |  | [optional] 
