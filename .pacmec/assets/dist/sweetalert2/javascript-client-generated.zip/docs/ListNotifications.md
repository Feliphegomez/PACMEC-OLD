# Pacmec.ListNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListnotificationsRecords]**](ListnotificationsRecords.md) |  | [optional] 
