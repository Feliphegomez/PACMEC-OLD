# Pacmec.GlossaryTxtApi

All URIs are relative to *https://pacmec.managertechnology.com.co/api.php*

Method | HTTP request | Description
------------- | ------------- | -------------
[**listGlossaryTxt**](GlossaryTxtApi.md#listGlossaryTxt) | **GET** /records/glossary_txt | 
[**readGlossaryTxt**](GlossaryTxtApi.md#readGlossaryTxt) | **GET** /records/glossary_txt/{id} | 

<a name="listGlossaryTxt"></a>
# **listGlossaryTxt**
> ListGlossaryTxt listGlossaryTxt(opts)



list glossary_txt

### Example
```javascript
import Pacmec from 'pacmec';

let apiInstance = new Pacmec.GlossaryTxtApi();
let opts = { 
  'filter': ["filter_example"], // [String] | Filters to be applied. Each filter consists of a column, an operator and a value (comma separated). Example: id,eq,1
  'include': "include_example", // String | Columns you want to include in the output (comma separated). Example: posts.*,categories.name
  'exclude': "exclude_example", // String | Columns you want to exclude from the output (comma separated). Example: posts.content
  'order': ["order_example"], // [String] | Column you want to sort on and the sort direction (comma separated). Example: id,desc
  'size': "size_example", // String | Maximum number of results (for top lists). Example: 10
  'page': "page_example", // String | Page number and page size (comma separated). Example: 1,10
  'join': ["join_example"] // [String] | Paths (comma separated) to related entities that you want to include. Example: comments,users
};
apiInstance.listGlossaryTxt(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filter** | [**[String]**](String.md)| Filters to be applied. Each filter consists of a column, an operator and a value (comma separated). Example: id,eq,1 | [optional] 
 **include** | **String**| Columns you want to include in the output (comma separated). Example: posts.*,categories.name | [optional] 
 **exclude** | **String**| Columns you want to exclude from the output (comma separated). Example: posts.content | [optional] 
 **order** | [**[String]**](String.md)| Column you want to sort on and the sort direction (comma separated). Example: id,desc | [optional] 
 **size** | **String**| Maximum number of results (for top lists). Example: 10 | [optional] 
 **page** | **String**| Page number and page size (comma separated). Example: 1,10 | [optional] 
 **join** | [**[String]**](String.md)| Paths (comma separated) to related entities that you want to include. Example: comments,users | [optional] 

### Return type

[**ListGlossaryTxt**](ListGlossaryTxt.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="readGlossaryTxt"></a>
# **readGlossaryTxt**
> ReadGlossaryTxt readGlossaryTxt(id, opts)



read glossary_txt

### Example
```javascript
import Pacmec from 'pacmec';

let apiInstance = new Pacmec.GlossaryTxtApi();
let id = "id_example"; // String | primary key value
let opts = { 
  'include': "include_example", // String | Columns you want to include in the output (comma separated). Example: posts.*,categories.name
  'exclude': "exclude_example", // String | Columns you want to exclude from the output (comma separated). Example: posts.content
  'join': ["join_example"] // [String] | Paths (comma separated) to related entities that you want to include. Example: comments,users
};
apiInstance.readGlossaryTxt(id, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| primary key value | 
 **include** | **String**| Columns you want to include in the output (comma separated). Example: posts.*,categories.name | [optional] 
 **exclude** | **String**| Columns you want to exclude from the output (comma separated). Example: posts.content | [optional] 
 **join** | [**[String]**](String.md)| Paths (comma separated) to related entities that you want to include. Example: comments,users | [optional] 

### Return type

[**ReadGlossaryTxt**](ReadGlossaryTxt.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

