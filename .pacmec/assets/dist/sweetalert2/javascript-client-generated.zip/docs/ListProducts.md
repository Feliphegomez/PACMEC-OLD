# Pacmec.ListProducts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListproductsRecords]**](ListproductsRecords.md) |  | [optional] 
