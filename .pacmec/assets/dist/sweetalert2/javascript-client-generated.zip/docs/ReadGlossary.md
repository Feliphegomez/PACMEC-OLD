# Pacmec.ReadGlossary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**isDefault** | **Number** |  | [optional] 
**tag** | **String** |  | [optional] 
