# Pacmec.ListMenusElements

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListmenusElementsRecords]**](ListmenusElementsRecords.md) |  | [optional] 
