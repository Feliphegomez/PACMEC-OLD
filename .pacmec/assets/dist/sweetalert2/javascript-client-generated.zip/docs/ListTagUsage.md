# Pacmec.ListTagUsage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | **[Object]** |  | [optional] 
