# Pacmec.ListpursesRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**wallet** | **Number** |  | [optional] 
**alias** | **String** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
