# Pacmec.ListWalletsHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListwalletsHistoryRecords]**](ListwalletsHistoryRecords.md) |  | [optional] 
