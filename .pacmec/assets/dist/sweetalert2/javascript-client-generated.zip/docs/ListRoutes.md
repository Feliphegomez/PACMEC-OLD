# Pacmec.ListRoutes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListroutesRecords]**](ListroutesRecords.md) |  | [optional] 
