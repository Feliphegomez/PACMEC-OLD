# Pacmec.ListproductsRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**price** | **String** |  | [optional] 
**properties** | **String** |  | [optional] 
**createdAt** | **Date** |  | [optional] 
**deletedAt** | **Date** |  | [optional] 
