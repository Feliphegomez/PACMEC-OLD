# Pacmec.ListbenefitsRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**membership** | **Number** |  | [optional] 
**feature** | **Number** |  | [optional] 
**text** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**reqReservation** | **Number** |  | [optional] 
**days** | **String** |  | [optional] 
**months** | **String** |  | [optional] 
**limitCycle** | **String** |  | [optional] 
**limitDay** | **Number** |  | [optional] 
**limitWeek** | **Number** |  | [optional] 
**limitMonth** | **Number** |  | [optional] 
**limitYear** | **Number** |  | [optional] 
**quantity** | **Number** |  | [optional] 
**amount** | **Number** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
