# Pacmec.ListwalletsRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**uid** | **String** |  | [optional] 
**puid** | **String** |  | [optional] 
**pin** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 
**status** | **String** |  | [optional] 
**balance** | **Number** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
