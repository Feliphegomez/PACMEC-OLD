# Pacmec.ListGlossaryTxt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListglossaryTxtRecords]**](ListglossaryTxtRecords.md) |  | [optional] 
