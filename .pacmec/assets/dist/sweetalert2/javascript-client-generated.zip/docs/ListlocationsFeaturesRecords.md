# Pacmec.ListlocationsFeaturesRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**location** | **Number** |  | [optional] 
**featureParent** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**icon** | **String** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
