# Pacmec.UpdateNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**isRead** | **Number** |  | [optional] 
