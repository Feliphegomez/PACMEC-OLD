# Pacmec.ReadMenusElements

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**menu** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**indexId** | **Number** |  | [optional] 
**tagId** | **String** |  | [optional] 
**tagHref** | **String** |  | [optional] 
**icon** | **String** |  | [optional] 
**_public** | **Number** |  | [optional] 
**alls** | **Number** |  | [optional] 
**guest** | **Number** |  | [optional] 
