# Pacmec.CreateComments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**routeId** | **Number** |  | [optional] 
**message** | **String** |  | [optional] 
