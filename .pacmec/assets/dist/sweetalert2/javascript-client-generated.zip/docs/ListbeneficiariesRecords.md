# Pacmec.ListbeneficiariesRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**names** | **String** |  | [optional] 
**surname** | **String** |  | [optional] 
**identificationType** | **Number** |  | [optional] 
**identificationNumber** | **String** |  | [optional] 
**mobile** | **String** |  | [optional] 
**address** | **String** |  | [optional] 
**country** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**arp** | **Number** |  | [optional] 
**bloodType** | **String** |  | [optional] 
**bloodRh** | **String** |  | [optional] 
**emergencyContact** | **String** |  | [optional] 
**emergencyPhone** | **String** |  | [optional] 
**enabled** | **Number** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
