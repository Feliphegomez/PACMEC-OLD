# Pacmec.ListNopk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListnopkRecords]**](ListnopkRecords.md) |  | [optional] 
