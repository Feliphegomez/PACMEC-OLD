# Pacmec.ListLocationsFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListlocationsFeaturesRecords]**](ListlocationsFeaturesRecords.md) |  | [optional] 
