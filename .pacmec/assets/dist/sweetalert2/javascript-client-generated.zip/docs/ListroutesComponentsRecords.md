# Pacmec.ListroutesComponentsRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**routeId** | **Number** |  | [optional] 
**component** | **String** |  | [optional] 
**ordering** | **Number** |  | [optional] 
**data** | **String** |  | [optional] 
