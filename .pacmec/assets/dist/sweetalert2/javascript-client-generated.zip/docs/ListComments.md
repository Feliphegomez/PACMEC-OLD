# Pacmec.ListComments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListcommentsRecords]**](ListcommentsRecords.md) |  | [optional] 
