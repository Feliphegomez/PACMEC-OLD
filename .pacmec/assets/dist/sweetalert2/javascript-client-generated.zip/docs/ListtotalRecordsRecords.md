# Pacmec.ListtotalRecordsRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tableName** | **String** |  | [optional] 
**tableRows** | **Number** |  | [optional] 
