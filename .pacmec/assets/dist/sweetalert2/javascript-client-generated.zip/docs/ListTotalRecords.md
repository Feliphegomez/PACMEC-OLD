# Pacmec.ListTotalRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListtotalRecordsRecords]**](ListtotalRecordsRecords.md) |  | [optional] 
