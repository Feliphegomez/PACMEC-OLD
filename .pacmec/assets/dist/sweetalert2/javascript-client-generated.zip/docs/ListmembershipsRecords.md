# Pacmec.ListmembershipsRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**initialPayment** | **String** |  | [optional] 
**billingAmount** | **String** |  | [optional] 
**cycleNumber** | **Number** |  | [optional] 
**cyclePeriod** | **String** |  | [optional] 
**allowSignups** | **Number** |  | [optional] 
**expirationNumber** | **Number** |  | [optional] 
**expirationPeriod** | **String** |  | [optional] 
**favorite** | **Number** |  | [optional] 
**maxMembers** | **Number** |  | [optional] 
**thumb** | **String** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
