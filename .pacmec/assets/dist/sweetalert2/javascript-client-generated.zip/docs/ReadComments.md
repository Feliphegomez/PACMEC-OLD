# Pacmec.ReadComments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**routeId** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**approved** | **Number** |  | [optional] 
**approvedPending** | **Number** |  | [optional] 
**message** | **String** |  | [optional] 
