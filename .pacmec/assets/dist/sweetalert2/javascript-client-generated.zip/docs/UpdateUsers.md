# Pacmec.UpdateUsers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**displayName** | **String** |  | [optional] 
**phones** | **String** |  | [optional] 
**location** | **String** |  | [optional] 
