# Pacmec.ListKunsthndvrk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListkunsthndvrkRecords]**](ListkunsthndvrkRecords.md) |  | [optional] 
