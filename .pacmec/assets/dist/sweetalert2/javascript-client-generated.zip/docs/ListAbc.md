# Pacmec.ListAbc

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListabcRecords]**](ListabcRecords.md) |  | [optional] 
