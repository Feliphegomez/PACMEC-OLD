# Pacmec.ListGlossary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListglossaryRecords]**](ListglossaryRecords.md) |  | [optional] 
