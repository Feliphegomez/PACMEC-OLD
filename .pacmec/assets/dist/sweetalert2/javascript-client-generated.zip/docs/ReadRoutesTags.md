# Pacmec.ReadRoutesTags

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**routeId** | **Number** |  | [optional] 
**tagId** | **Number** |  | [optional] 
