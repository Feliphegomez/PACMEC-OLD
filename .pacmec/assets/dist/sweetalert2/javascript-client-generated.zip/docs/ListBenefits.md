# Pacmec.ListBenefits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListbenefitsRecords]**](ListbenefitsRecords.md) |  | [optional] 
