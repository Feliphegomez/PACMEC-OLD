# Pacmec.ListtestimonilasRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**user** | **Number** |  | [optional] 
**email** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**comment** | **String** |  | [optional] 
**_public** | **Number** |  | [optional] 
**vote** | **Number** |  | [optional] 
