# Pacmec.ReadNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**data** | **String** |  | [optional] 
**isRead** | **Number** |  | [optional] 
**created** | **Date** |  | [optional] 
**updated** | **Date** |  | [optional] 
