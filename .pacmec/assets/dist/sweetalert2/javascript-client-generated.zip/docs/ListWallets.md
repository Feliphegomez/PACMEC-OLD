# Pacmec.ListWallets

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListwalletsRecords]**](ListwalletsRecords.md) |  | [optional] 
