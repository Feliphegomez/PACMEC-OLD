# Pacmec.UpdateBeneficiaries

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**names** | **String** |  | [optional] 
**surname** | **String** |  | [optional] 
**identificationType** | **Number** |  | [optional] 
**identificationNumber** | **String** |  | [optional] 
**mobile** | **String** |  | [optional] 
**address** | **String** |  | [optional] 
**country** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**arp** | **Number** |  | [optional] 
**bloodType** | **String** |  | [optional] 
**bloodRh** | **String** |  | [optional] 
**emergencyContact** | **String** |  | [optional] 
**emergencyPhone** | **String** |  | [optional] 
