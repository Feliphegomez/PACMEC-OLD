# Pacmec.ListusersRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**isAdmin** | **Number** |  | [optional] 
**username** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**displayName** | **String** |  | [optional] 
**phones** | **String** |  | [optional] 
**hash** | **String** |  | [optional] 
**location** | **String** |  | [optional] 
**list** | **String** |  | [optional] 
**create** | **String** |  | [optional] 
**read** | **String** |  | [optional] 
**update** | **String** |  | [optional] 
**_delete** | **String** |  | [optional] 
**increment** | **String** |  | [optional] 
**permissions** | **String** |  | [optional] 
