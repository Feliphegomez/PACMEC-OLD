# Pacmec.ReadRoutes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**isActived** | **Number** |  | [optional] 
**parent** | **Number** |  | [optional] 
**permissionAccess** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**requestUri** | **String** |  | [optional] 
**component** | **String** |  | [optional] 
