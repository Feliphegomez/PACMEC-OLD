# Pacmec.ListkunsthndvrkRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**umlautsCOUNT** | **Number** |  | [optional] 
**userId** | **Number** |  | [optional] 
**invisible** | **String** |  | [optional] 
**invisibleId** | **String** |  | [optional] 
