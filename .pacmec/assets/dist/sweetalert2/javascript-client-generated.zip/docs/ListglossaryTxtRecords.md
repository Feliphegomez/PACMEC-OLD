# Pacmec.ListglossaryTxtRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**glossaryId** | **Number** |  | [optional] 
**slug** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
