# Pacmec.ListRoutesComponents

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | **Number** |  | [optional] 
**records** | [**[ListroutesComponentsRecords]**](ListroutesComponentsRecords.md) |  | [optional] 
