# Pacmec.ReadLocations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**icon** | **String** |  | [optional] 
**areaParent** | **Number** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
**location** | **String** |  | [optional] 
