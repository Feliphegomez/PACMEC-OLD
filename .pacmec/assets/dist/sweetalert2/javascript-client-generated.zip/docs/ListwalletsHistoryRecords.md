# Pacmec.ListwalletsHistoryRecords

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**wallet** | **Number** |  | [optional] 
**action** | **String** |  | [optional] 
**amount** | **Number** |  | [optional] 
**newBalance** | **Number** |  | [optional] 
**balance** | **Number** |  | [optional] 
**created** | **Date** |  | [optional] 
**createdBy** | **Number** |  | [optional] 
**modified** | **Date** |  | [optional] 
**modifiedBy** | **Number** |  | [optional] 
