<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
?>
    <?php
      if(!isset($GLOBALS['PACMEC']['route']->is_embeded) || $GLOBALS['PACMEC']['route']->is_embeded !== true){
        get_template_part('template-parts/footer/site-footer');
      }
    ?>

    <a href="#" class="scroll-top" id="scroll-top">
        <i class="arrow-top fa fa-long-arrow-up"></i>
        <i class="arrow-bottom fa fa-long-arrow-up"></i>
    </a>

    <div class="modalquickview modal modal-md fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button class="btn close" data-bs-dismiss="modal">×</button>
                <div class="row">
                    <div class="col-12">
                      <iframe id="modal-embeded-iframe" class="frame-box-modal" height="450px"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php pacmec_foot(); ?>
    <script>
      window.addEventListener('load', function(){
        $('#exampleModalCenter').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget) // Button that triggered the modal
          var product = button.data('product') // Extract info from data-* attributes
          var urli = '/<?= $GLOBALS['PACMEC']['permanents_links']['%products_embeded%']; ?>/'+product+'/embeded';
          console.log('product', product)
          console.log('urli', urli)
          $("#modal-embeded-iframe").attr('src', urli);
        })
      });
    </script>
    
  </body>
</html>
