<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */

function mt_destry_socials_icons($atts, $content="")
{
  try {
    $args = shortcode_atts([
      "target" => "_blank",
      "enable_tag" => false,
      "class" => 'widget-social',
      "menu_slug" => "socials_links",
    ], $atts);
    $menu_social = \pacmec_load_menu($args['menu_slug']);
    if ($menu_social !== false):
      foreach ($menu_social->items as $i => $item):
        if(!empty($item->icon)) $content .= "<a target=\"{$args['target']}\" title=\"{$item->title}\" href=\"{$item->tag_href}\"><i class=\"{$item->icon}\"></i></a>\n";
      endforeach;
    endif;
    return \PHPStrap\Util\Html::tag('div', $content, $args['class'], []);
  } catch (\Exception $e) {
    return "Ups: mt_destry_socials_icons: " . $e->getMessage();
  }
}
add_shortcode('mt_destry-socials-icons', 'mt_destry_socials_icons');

function mt_destry_footer_menu($atts, $content="")
{
  try {
    $args = shortcode_atts([
      "class" => 'single-footer-widget',
      "menu_slug" => false,
      "title" => false,
    ], $atts);
    $title = ($args['title']!==false) ? \PHPStrap\Util\Html::tag('h2', __a('information'), ['widget-title'], []) : "";
    $items = "";
    if($args['menu_slug']):
      $_menu = \pacmec_load_menu($args['menu_slug']);
      if ($_menu !== false) foreach ($_menu->items as $key => $item) { $items .= pacmec_menu_item_to_li($item, [], [], false, true, true, ['sub-menu'], [], []); }
    endif;
    return \PHPStrap\Util\Html::tag('div', $title.\PHPStrap\Util\Html::tag('ul', $items, ['widget-list'], []), $args['class'], []);
  } catch (\Exception $e) {
    return "Ups: mt_destry_footer_menu: " . $e->getMessage();
  }
}
add_shortcode('mt_destry-footer-menu', 'mt_destry_footer_menu');

function mt_destry_hero_slider($atts, $content="")
{
  try {
    $args = shortcode_atts([
      "icon-prev" => 'pe-7s-angle-left',
      "icon-next" => 'pe-7s-angle-right',
      "pagination" => true,
      "hero_item_class" => "hero-slide-item-two swiper-slide",
      "steps" => "W3sidGl0bGUiOiJ0aXRsZSIsInBpY3R1cmUiOiJcLy5wYWNtZWNcL3RoZW1lc1wvbXQtZGVzdHJ5XC9hc3NldHNcL2ltYWdlc1wvc2xpZGVyXC9zbGlkZS0yLmpwZyIsImNvbnRlbnQiOiJjb250ZW50IiwiYnRucyI6W3sidHh0IjoiYnRuIiwiY2xhc3MiOiJidG4gYnRuLWxnIGJ0bi1wcmltYXJ5IGJ0bi1ob3Zlci1kYXJrIiwibGluayI6IiMifV19LHsidGl0bGUiOiJ0aXRsZSIsInBpY3R1cmUiOiJcLy5wYWNtZWNcL3RoZW1lc1wvbXQtZGVzdHJ5XC9hc3NldHNcL2ltYWdlc1wvc2xpZGVyXC9zbGlkZS0yLmpwZyIsImNvbnRlbnQiOiJjb250ZW50In1d",
    ], $atts);
    $items = "";
    if(isset($args['steps'])){
      $args['steps'] = json_decode(base64_decode($args['steps']));
      if(json_decode(json_encode($args['steps'])) == $args['steps']){
        foreach ($args['steps'] as $f) {
          $btns = "";
          if(isset($f->btns)){
            foreach ($f->btns as $btn) {
              if(isset($btn->txt) && isset($btn->class) && isset($btn->link)) $btns .= \PHPStrap\Util\Html::tag('a', $btn->txt, [$btn->class], ['href'=>$btn->link]);
            }
          }
          $hero_content_p = \PHPStrap\Util\Html::tag('p', __a($f->content), [], []);
          $hero_content_title = \PHPStrap\Util\Html::tag('h2', __a($f->title), ['title'], []);
          $hero_content = \PHPStrap\Util\Html::tag('div', $hero_content_title.$hero_content_p.$btns, ['hero-slide-content col-lg-8 col-xl-6 col-12 text-lg-center text-left'], []);
          $hero_row = \PHPStrap\Util\Html::tag('div', $hero_content, ['row'], []);
          $hero_container = \PHPStrap\Util\Html::tag('div', $hero_row, ['container'], []);
          $hero_slide_bg_img = \PHPStrap\Util\Html::tag('img', '', [], ['src'=>$f->picture], true);
          $hero_slide_bg = \PHPStrap\Util\Html::tag('div', $hero_slide_bg_img, ['hero-slide-bg'], []);
          $items .= \PHPStrap\Util\Html::tag('div', $hero_slide_bg.$hero_container, ['hero-slide-item-two swiper-slide'], []);
        }
      }
    }
    $slider_prev = \PHPStrap\Util\Html::tag('div', \PHPStrap\Util\Html::tag('i', '', [$args["icon-prev"]], []), ['home-slider-prev swiper-button-prev main-slider-nav d-md-flex d-none'], []);
    $slider_next = \PHPStrap\Util\Html::tag('div', \PHPStrap\Util\Html::tag('i', '', [$args["icon-next"]], []), ['home-slider-next swiper-button-next main-slider-nav d-md-flex d-none'], []);
    $swiper_pagination = \PHPStrap\Util\Html::tag('div', '', ['swiper-pagination d-md-none'], []);
    $swiper_wrapper = \PHPStrap\Util\Html::tag('div', $items, ['swiper-wrapper'], []);
    $swiper_container = \PHPStrap\Util\Html::tag('div', $swiper_wrapper.$swiper_pagination.$slider_prev.$slider_next, ['swiper-container'], []);
    $div_r = \PHPStrap\Util\Html::tag('div', $swiper_container, ['hero-slider'], []);
    return $div_r;
  } catch (\Exception $e) {
    return "Ups: mt_destry_hero_slider: " . $e->getMessage();
  }
}
add_shortcode('mt_destry-hero-slider', 'mt_destry_hero_slider');

function mt_destry_feature_wrap($atts, $content="")
{
  try {
    $args = shortcode_atts([
      "icons" => "W3sidGl0bGUiOiJmcmVlX3NoaXBwaW5nX3RpdGxlIiwiY29udGVudCI6ImZyZWVfc2hpcHBpbmdfY29udGVudCIsInBpY3R1cmUiOiJcLy5wYWNtZWNcL3RoZW1lc1wvbXQtZGVzdHJ5XC9hc3NldHNcL2ltYWdlc1wvaWNvbnNcL2ZlYXR1cmUtaWNvbi0yLnBuZyJ9LHsidGl0bGUiOiJzdXBwb3J0X2hvdXJzX3RpdGxlIiwiY29udGVudCI6InN1cHBvcnRfaG91cnNfY29udGVudCIsInBpY3R1cmUiOiJcLy5wYWNtZWNcL3RoZW1lc1wvbXQtZGVzdHJ5XC9hc3NldHNcL2ltYWdlc1wvaWNvbnNcL2ZlYXR1cmUtaWNvbi0zLnBuZyJ9LHsidGl0bGUiOiJtb25leV9yZXR1cm5fdGl0bGUiLCJjb250ZW50IjoibW9uZXlfcmV0dXJuX2NvbnRlbnQiLCJwaWN0dXJlIjoiXC8ucGFjbWVjXC90aGVtZXNcL210LWRlc3RyeVwvYXNzZXRzXC9pbWFnZXNcL2ljb25zXC9mZWF0dXJlLWljb24tNC5wbmcifSx7InRpdGxlIjoib3JkZXJfZGlzY291bnRfdGl0bGUiLCJjb250ZW50Ijoib3JkZXJfZGlzY291bnRfY29udGVudCIsInBpY3R1cmUiOiJcLy5wYWNtZWNcL3RoZW1lc1wvbXQtZGVzdHJ5XC9hc3NldHNcL2ltYWdlc1wvaWNvbnNcL2ZlYXR1cmUtaWNvbi0xLnBuZyJ9XQ==",
      "class" => "feature-wrap",
    ], $atts);
    $args['icons'] = json_decode(base64_decode($args['icons']));
    $items = "";
    if(json_decode(json_encode($args['icons'])) == $args['icons']){
      foreach ($args['icons'] as $icon) {
        if(
          isset($icon->picture)
          && isset($icon->title)
          && isset($icon->content)
        ){
          $col_mb_feature_icon_box_img = \PHPStrap\Util\Html::tag('img', '', [], ['src'=>$icon->picture]);
          $col_mb_feature_icon_box = \PHPStrap\Util\Html::tag('div', $col_mb_feature_icon_box_img, ['icon text-primary align-self-center'], []);
          $col_mb_feature_content_box_title = \PHPStrap\Util\Html::tag('h5', __a($icon->title), ['title'], []);
          $col_mb_feature_content_box_content = \PHPStrap\Util\Html::tag('p', __a($icon->content), [], []);
          $col_mb_feature_content_box = \PHPStrap\Util\Html::tag('div', $col_mb_feature_content_box_title.$col_mb_feature_content_box_content, ['content'], []);
          $col_mb_feature = \PHPStrap\Util\Html::tag('div', $col_mb_feature_icon_box.$col_mb_feature_content_box, ['feature'], []);
          $items .= \PHPStrap\Util\Html::tag('div', $col_mb_feature, ['col mb-5" data-aos="fade-up" data-aos-delay="300'], []);
        }
      }
    }
    $rows = \PHPStrap\Util\Html::tag('div', $items, ['row row-cols-lg-4 row-cols-xl-auto row-cols-sm-2 row-cols-1 justify-content-between mb-n5'], []);
    return \PHPStrap\Util\Html::tag('div', $rows, [$args['class']], []);
  } catch (\Exception $e) {
  return "Ups: mt_destry_feature_wrap: " . $e->getMessage();
  }
}
add_shortcode('mt_destry-feature-wrap', 'mt_destry_feature_wrap');

function mt_destry_banners($atts, $content="")
{
  try {
    $args = shortcode_atts([
      "steps" => "W3sidGl0bGUiOiJ0aXRsZSIsInBpY3R1cmUiOiJcLy5wYWNtZWNcL3RoZW1lc1wvbXQtZGVzdHJ5XC9hc3NldHNcL2ltYWdlc1wvc2xpZGVyXC9zbGlkZS0yLmpwZyIsImNvbnRlbnQiOiJjb250ZW50IiwiYnRucyI6W3sidHh0IjoiYnRuIiwiY2xhc3MiOiJidG4gYnRuLWxnIGJ0bi1wcmltYXJ5IGJ0bi1ob3Zlci1kYXJrIiwibGluayI6IiMifV19LHsidGl0bGUiOiJ0aXRsZSIsInBpY3R1cmUiOiJcLy5wYWNtZWNcL3RoZW1lc1wvbXQtZGVzdHJ5XC9hc3NldHNcL2ltYWdlc1wvc2xpZGVyXC9zbGlkZS0yLmpwZyIsImNvbnRlbnQiOiJjb250ZW50In0seyJ0aXRsZSI6InRpdGxlIiwicGljdHVyZSI6IlwvLnBhY21lY1wvdGhlbWVzXC9tdC1kZXN0cnlcL2Fzc2V0c1wvaW1hZ2VzXC9zbGlkZXJcL3NsaWRlLTIuanBnIiwiY29udGVudCI6ImNvbnRlbnQifSx7InRpdGxlIjoidGl0bGUiLCJwaWN0dXJlIjoiXC8ucGFjbWVjXC90aGVtZXNcL210LWRlc3RyeVwvYXNzZXRzXC9pbWFnZXNcL3NsaWRlclwvc2xpZGUtMi5qcGciLCJjb250ZW50IjoiY29udGVudCJ9XQ==",
      "class" => "row mb-n6 overflow-hidden",
      "columns_class" => 'col-md-6 col-12 mb-6'
    ], $atts);
    $args['steps'] = json_decode(base64_decode($args['steps']));
    $items = "";
    if(json_decode(json_encode($args['steps'])) == $args['steps']){
      foreach ($args['steps'] as $icon) {
        if(
          isset($icon->picture)
          && isset($icon->title)
          && isset($icon->content)
        ){
          $banner_image_img =\PHPStrap\Util\Html::tag('img', '', [], ["src"=>"/.pacmec/themes/mt-destry/assets/images/banner/banner-4.jpg"], true);
          $banner_image_a   = \PHPStrap\Util\Html::tag('div', $banner_image_img, [], ["href"=>"#"]);
          $banner_image     = \PHPStrap\Util\Html::tag('div', $banner_image_a, ['banner-image'], []);
          $btns = "";
          if(isset($icon->btns)){
            foreach ($icon->btns as $btn) {
              if(isset($btn->txt) && isset($btn->class) && isset($btn->link)) $btns .= \PHPStrap\Util\Html::tag('a', $btn->txt, [$btn->class], ['href'=>$btn->link]);
            }
          }
          $info_title        = \PHPStrap\Util\Html::tag('div', __a($icon->title), ['title'], []);
          $info_sub_title        = \PHPStrap\Util\Html::tag('div', __a($icon->content), ['sub-title'], []);
          $info_content     = \PHPStrap\Util\Html::tag('div', $info_sub_title.$info_title.$btns, ['small-banner-content'], []);
          $info             = \PHPStrap\Util\Html::tag('div', $info_content, ['info'], []);
          $box = \PHPStrap\Util\Html::tag('div', $banner_image.$info, ['banner'], ["data-aos"=>"fade-right", "data-aos-delay"=>"300"]);
          $items .= \PHPStrap\Util\Html::tag('div', $box, [$args['columns_class']], []);
        }
      }
    }
    return \PHPStrap\Util\Html::tag('div', $items, [$args['class']], []);
  } catch (\Exception $e) {
  return "Ups: mt_destry_feature_wrap: " . $e->getMessage();
  }
}
add_shortcode('mt_destry-banners', 'mt_destry_banners');

function mt_destry_product_style1($_product, $class=[], $attrs=[])
{
  $url_product = $_product->link_href;
  $_img_box_a_img1 = \PHPStrap\Util\Html::tag('img', '', ['first-image'], ['src'=>$_product->thumb], true);
  $sec_img = (isset($_product->gallery[1])) ? $_product->gallery[1] : $_product->thumb;
  $_img_box_a_img2 = \PHPStrap\Util\Html::tag('img', '', ['second-image'], ['src'=>$sec_img], true);
  $_img_box_a = \PHPStrap\Util\Html::tag('a', $_img_box_a_img1.$_img_box_a_img2, ['image'], ["href"=>$url_product]);
  $btns = "";
  $btns .= \PHPStrap\Util\Html::tag('a', \PHPStrap\Util\Html::tag('i', '', ['pe-7s-search'], []), ['action quickview'], ['data-bs-toggle'=>'modal', "data-bs-target"=>"#exampleModalCenter", "data-product"=>$_product->id]);
  $_box_actions = \PHPStrap\Util\Html::tag('div', $btns, ['actions'], []);
  $badges = "";
  if($_product->in_promo == true){
    $badges .= \PHPStrap\Util\Html::tag('span', \PHPStrap\Util\Html::tag('span', (100 - (int) (($_product->price_promo*100) / $_product->price_normal))."%", ['sale'], []), ['badges'], []);
  }
  if(!($_product->available>0)){
    $badges .= \PHPStrap\Util\Html::tag('span', \PHPStrap\Util\Html::tag('span', __a('product_not_available'), ['sale'], []), ['badges'], []);
  }
  $_img_box = \PHPStrap\Util\Html::tag('div', $_img_box_a.$_box_actions.$badges, ['thumb'], []);
  $_cont_box_subtitle = \PHPStrap\Util\Html::tag('h4', \PHPStrap\Util\Html::tag('a', $_product->common_names, [], ["href"=>$url_product]), ['sub-title'], []);
  $_cont_box_title = \PHPStrap\Util\Html::tag('h5', \PHPStrap\Util\Html::tag('a', $_product->name, [], ["href"=>$url_product]), ['title'], []);
  $ratings = \PHPStrap\Util\Html::tag('span',
    \PHPStrap\Util\Html::tag('span',
      \PHPStrap\Util\Html::tag('span', '', ['star'], ["style"=>"width: {$_product->rating_porcen}%"])
    , ['rating-wrap'], [])
    . \PHPStrap\Util\Html::tag('span', "({$_product->rating_number})", ['rating-num'], [])
  , ['ratings'], []);

  $_prices = "";
  if($_product->in_promo == true){
    $_prices .= \PHPStrap\Util\Html::tag('span', formatMoney($_product->price_promo), ['new'], []);
    $_prices .= \PHPStrap\Util\Html::tag('span', formatMoney($_product->price_normal), ['old'], []);
  } else {
    $_prices .= \PHPStrap\Util\Html::tag('span', formatMoney($_product->price_normal), ['new'], []);
  }
  $prices = \PHPStrap\Util\Html::tag('span', $_prices, ['price'], []);

  $_cont_box = \PHPStrap\Util\Html::tag('div', $_cont_box_subtitle.$_cont_box_title.$ratings.$prices
    /*. (($_product->available>0)
      ? '<button class="btn btn-sm btn-outline-dark btn-hover-primary">'.__a('add_to_cart').'</button>'
      : '<button class="btn btn-sm btn-outline-dark btn-hover-primary disabled" disabled>'.__a('product_not_available').'</button>'
      )
    */
  , ['content'], []);
  return \PHPStrap\Util\Html::tag('div', $_img_box.$_cont_box, $class, $attrs);
}

function mt_destry_products_section($atts, $content="")
{
  try {
    if(\plugin_is_active("PIM")==false) return "Plugin PIM NO ACTIVO";

    $args = shortcode_atts([
      "class" => "section section-padding mt-0",
      "tabs"  => 'new_products',
      "limit"  => '12',
      "btns"  => 'wishlist,compare,quickview'
    ], $atts);
    $args['tabs'] = explode(',', $args['tabs']);
    $args['btns'] = explode(',', $args['btns']);
    $rows = "";
    $lis = "";
    $items_p = "";
    if(in_array('new_products', ($args['tabs']))) {
      $lis .= \PHPStrap\Util\Html::tag('li', \PHPStrap\Util\Html::tag('a', __a('new_arrivals'), ['nav-link mt-3 active'], ["data-bs-toggle"=>"tab", "href"=>"#tab-product-new_products"]), ['nav-item'], ["data-aos"=>"fade-up", "data-aos-delay"=>"300"]);
    }
    // Tab Start
    $rows .= \PHPStrap\Util\Html::tag('div',
      \PHPStrap\Util\Html::tag('div',
        \PHPStrap\Util\Html::tag('ul', $lis, ['product-tab-nav nav justify-content-center mb-10 title-border-bottom mt-n3'], [])
      , ['col-12'], [])
    , ['row'], []);
    // Tab End
    $_products = \PACMEC\System\Products::allNews($args['limit']);
    foreach ($_products as $_product) {
      $product = mt_destry_product_style1($_product, ['product product-border-left mb-10'], ["data-aos"=>"fade-up", "data-aos-delay"=>"300"]);
      $items_p .= \PHPStrap\Util\Html::tag('div', $product, ['swiper-slide product-wrapper'], []);
    }
    $rows .= \PHPStrap\Util\Html::tag('div',
      \PHPStrap\Util\Html::tag('div',
        \PHPStrap\Util\Html::tag('div',
          \PHPStrap\Util\Html::tag('div',
            \PHPStrap\Util\Html::tag('div',
              \PHPStrap\Util\Html::tag('div',
                \PHPStrap\Util\Html::tag('div',
                  $items_p
                , ['swiper-wrapper'], [])
              , ['swiper-container'], [])
            , ['product-carousel'], [])
          , ['tab-pane fade show active'], ['id'=>'tab-product-new_products'])
        , ['tab-content position-relative'], [])
      , ['col'], [])
    , ['row'], []);
    $container = \PHPStrap\Util\Html::tag('div', $rows, ['container'], []);
    return \PHPStrap\Util\Html::tag('div', $container, [$args['class']], []);
  } catch (\Exception $e) {
    return "Ups: mt_destry_feature_wrap: " . $e->getMessage();
  }
}
add_shortcode('mt_destry-products-section', 'mt_destry_products_section');

function mt_destry_banner_fullwidth($atts, $content="")
{
  $args = shortcode_atts([
    "picture" => '%2F.pacmec%2Fthemes%2Fmt-destry%2Fassets%2Fimages%2Fbanner%2Fbig-banner.jpg',
    "link" => "#",
  ], $atts);
  $banner_image_a_img = \PHPStrap\Util\Html::tag('img', '', [], ["src"=>urldecode($args['picture'])]);
  $banner_image_a = \PHPStrap\Util\Html::tag('a', $banner_image_a_img, [], ['href'=>$args['link']]);
  $banner_image = \PHPStrap\Util\Html::tag('div', $banner_image_a, ['banner-image'], []);
  $banner = \PHPStrap\Util\Html::tag('div', $banner_image, ['banner'], []);
  $col = \PHPStrap\Util\Html::tag('div', $banner, ['col-12'], ["data-aos"=>"fade-up", "data-aos-delay"=>"300"]);
  $row = \PHPStrap\Util\Html::tag('div', $col, ['row'], []);
  $container = \PHPStrap\Util\Html::tag('div', $row, ['container'], []);
  return \PHPStrap\Util\Html::tag('div', $container, ['section'], []);
}
add_shortcode('mt_destry-banner-fullwidth', 'mt_destry_banner_fullwidth');

function mt_destry_social_share($atts, $content="")
{
  $args = shortcode_atts([
  ], $atts);
  $links = "";
  $link_uri = urlencode(infosite('siteurl').$GLOBALS['PACMEC']['path']);
  $troute = urlencode($GLOBALS['PACMEC']['route']->title);

  // MORE URLS https://crunchify.com/list-of-all-social-sharing-urls-for-handy-reference-social-media-sharing-buttons-without-javascript/
  $url_facebook = "https://www.facebook.com/sharer.php?u={$link_uri}";
  $url_twitter = "https://twitter.com/share?url={$link_uri}&text={$troute}";
  $url_linkedin = "https://www.linkedin.com/shareArticle?url={$link_uri}&title={$troute}";
  // $url_pinterest = "https://pinterest.com/pin/create/bookmarklet/?media=[post-img]&url=[post-url]&is_video=[is_video]&description=[post-title]";

  $links .= \PHPStrap\Util\Html::tag('a', \PHPStrap\Util\Html::tag('i', '', ['fa fa-facebook-square facebook-color'], []), [], ["href"=>$url_facebook, "target"=>"_blank"]);
  $links .= \PHPStrap\Util\Html::tag('a', \PHPStrap\Util\Html::tag('i', '', ['fa fa-twitter-square twitter-color'], []), [], ["href"=>$url_twitter, "target"=>"_blank"]);
  $links .= \PHPStrap\Util\Html::tag('a', \PHPStrap\Util\Html::tag('i', '', ['fa fa-linkedin-square linkedin-color'], []), [], ["href"=>$url_linkedin, "target"=>"_blank"]);
  // $links .= \PHPStrap\Util\Html::tag('a', \PHPStrap\Util\Html::tag('i', '', ['fa fa-pinterest-square pinterest-color'], []), [], ["href"=>$url_pinterest, "target"=>"_blank"]);
  $title = \PHPStrap\Util\Html::tag('span', __a('share_social'), [], []);
  return \PHPStrap\Util\Html::tag('div', $title.$links, ['social-share'], []);
}
add_shortcode('mt_destry-social-share', 'mt_destry_social_share');
