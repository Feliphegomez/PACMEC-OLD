<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
global $PACMEC;
$glossary_id = $GLOBALS['PACMEC']['glossary'][$GLOBALS['PACMEC']["lang"]]['id'];
$glossary_name = $GLOBALS['PACMEC']['glossary'][$GLOBALS['PACMEC']["lang"]]['name'];
$menu_primary = \pacmec_load_menu('primary_destry');
# echo json_encode($menu_primary, JSON_PRETTY_PRINT);
$r_html = "";
$r_html_mobile = "";
if($menu_primary !== false){
  foreach ($menu_primary->items as $key => $item) {
    $r_html .= pacmec_menu_item_to_li($item, ['has-children'], [], true, true, true, ['sub-menu'], [], []);
    $r_html_mobile .= pacmec_menu_item_to_li($item, [(count($item->childs)>0) ? 'has-children' : ''], [], true, true, true, [(count($item->childs)>0) ? 'dropdown' : ''], [], []);
  }
}
?>
<style>
.main-menu>ul>li>a {
  font-size: 12px !important;
}
.main-menu ul .has-children {
  margin-left: 9px;
}
.sitelogo {
  max-height: 63px;
  height: 63px;
}
</style>
<div class="header section">
  <div class="header-top bg-light">
      <div class="container">
          <div class="row row-cols-xl-2 align-items-center">
              <div class="col d-none d-lg-block">
                  <div class="header-top-lan-curr-link">
                      <div class="header-top-lan dropdown">
                          <button class="dropdown-toggle" data-bs-toggle="dropdown"><?= $glossary_name; ?> <i class="fa fa-angle-down"></i></button>
                          <ul class="dropdown-menu dropdown-menu-right animate slideIndropdown">
                              <?php foreach ($PACMEC['glossary'] as $tag => $info): ?>
                                <li><a class="dropdown-item" href="<?= site_url('/?lang='.$tag); ?>"><?= $info['name']; ?></a></li>
                              <?php endforeach; ?>
                          </ul>
                      </div>
                      <!--//
                      <div class="header-top-curr dropdown">
                          <button class="dropdown-toggle" data-bs-toggle="dropdown">USD <i class="fa fa-angle-down"></i></button>
                          <ul class="dropdown-menu dropdown-menu-right animate slideIndropdown">
                              <li><a class="dropdown-item" href="#">USD</a></li>
                              <li><a class="dropdown-item" href="#">Pound</a></li>
                          </ul>
                      </div>
                      -->
                      <div class="header-top-links">
                          <span><?= __a('call_us'); ?></span><a href="#"> <?= infosite('business_phone_number'); ?></a>
                      </div>
                  </div>
              </div>
              <div class="col">
                  <p class="header-top-message">Ends Monday: $100 off any dining table + 2 sets of chairs. <a href="shop-grid.html">Shop Now</a></p>
              </div>
          </div>
      </div>
  </div>
  <div class="header-bottom">
      <div class="header-sticky">
          <div class="container">
              <div class="row align-items-center">
                  <div class="col-xl-1 col-6">
                    <div class="header-logo">
                      <a href="<?= siteinfo('siteurl').siteinfo('homeurl'); ?>">
                        <?php if(siteinfo('sitelogo') !== 'NaN' && !empty(siteinfo('sitelogo'))): ?>
                          <img class="sitelogo" src="<?= siteinfo('sitelogo'); ?>" alt="<?= siteinfo('sitename'); ?> Logo" />
                        <?php else: ?>
                          <?= siteinfo('sitename'); ?>
                        <?php endif; ?>
                      </a>
                    </div>
                  </div>
                  <div class="col-xl-9 d-none d-xl-block">
                      <div class="main-menu position-relative">
                          <ul>
                              <?= $r_html; ?>
                              <!-- //
                              <li class="has-children position-static">
                                  <a href="#"><span>Shop</span> <i class="fa fa-angle-down"></i></a>
                                  <ul class="mega-menu row-cols-4">
                                      <li class="col">
                                          <h4 class="mega-menu-title">Shop Layout</h4>
                                          <ul class="mb-n2">
                                              <li><a href="shop-grid.html">Shop Grid</a></li>
                                              <li><a href="shop-left-sidebar.html">Left Sidebar</a></li>
                                              <li><a href="shop-right-sidebar.html">Right Sidebar</a></li>
                                              <li><a href="shop-list-fullwidth.html">List Fullwidth</a></li>
                                              <li><a href="shop-list-left-sidebar.html">List Left Sidebar</a></li>
                                              <li><a href="shop-list-right-sidebar.html">List Right Sidebar</a></li>
                                          </ul>
                                      </li>
                                      <li class="col">
                                          <h4 class="mega-menu-title">Product Layout</h4>
                                          <ul class="mb-n2">
                                              <li><a href="single-product.html">Single Product</a></li>
                                              <li><a href="single-product-sale.html">Single Product Sale</a></li>
                                              <li><a href="single-product-group.html">Single Product Group</a></li>
                                              <li><a href="single-product-normal.html">Single Product Normal</a></li>
                                              <li><a href="single-product-affiliate.html">Single Product Affiliate</a></li>
                                              <li><a href="single-product-slider.html">Single Product Slider</a></li>
                                          </ul>
                                      </li>
                                      <li class="col">
                                          <h4 class="mega-menu-title">Product Layout</h4>
                                          <ul class="mb-n2">
                                              <li><a href="single-product-gallery-left.html">Gallery Left</a></li>
                                              <li><a href="single-product-gallery-right.html">Gallery Right</a></li>
                                              <li><a href="single-product-tab-style-left.html">Tab Style Left</a></li>
                                              <li><a href="single-product-tab-style-right.html">Tab Style Right</a></li>
                                              <li><a href="single-product-sticky-left.html">Sticky Left</a></li>
                                              <li><a href="single-product-sticky-right.html">Sticky Right</a></li>
                                          </ul>
                                      </li>
                                      <li class="col">
                                          <h4 class="mega-menu-title">Other Pages</h4>
                                          <ul class="mb-n2">
                                              <li><a href="my-account.html">My Account</a></li>
                                              <li><a href="login-register.html">Loging | Register</a></li>
                                              <li><a href="wishlist.html">Wishlist</a></li>
                                              <li><a href="cart.html">Cart</a></li>
                                              <li><a href="checkout.html">Checkout</a></li>
                                              <li><a href="compare.html">Compare</a></li>
                                          </ul>
                                      </li>
                                  </ul>
                              </li>
                              -->
                          </ul>
                      </div>
                  </div>
                  <div class="col-xl-2 col-6">
                      <div class="header-actions">
                          <a href="javascript:void(0)" class="header-action-btn header-action-btn-search"><i class="pe-7s-search"></i></a>
                          <?php if (\isUser()): ?>
                            <a href="<?= __url_s("/%pacmec_meaccount%"); ?>" class="header-action-btn d-md-block"><i class="pe-7s-user"></i></a>
                          <?php else: ?>
                            <a href="<?= __url_s("/%pacmec_signin%"); ?>" class="header-action-btn d-md-block"><i class="fa fa-sign-in"></i></a>
                          <?php endif; ?>
                          <!--//<a href="wishlist.html" class="header-action-btn header-action-btn-wishlist d-none d-md-block">
                              <i class="pe-7s-like"></i>
                          </a>-->
                          <a href="javascript:void(0)" class="header-action-btn header-action-btn-cart">
                              <i class="pe-7s-shopbag"></i>
                              <span class="header-action-num"><?= count($PACMEC['session']->shopping_cart); ?></span>
                          </a>
                          <a href="javascript:void(0)" class="header-action-btn header-action-btn-menu d-xl-none d-lg-block">
                              <i class="fa fa-bars"></i>
                          </a>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <!-- Header Bottom End -->
  <!-- Mobile Menu Start -->
  <div class="mobile-menu-wrapper">
      <div class="offcanvas-overlay"></div>
      <div class="mobile-menu-inner">
          <div class="offcanvas-btn-close">
              <i class="pe-7s-close"></i>
          </div>
          <div class="mobile-navigation">
              <nav>
                  <ul class="mobile-menu">
                      <?= $r_html_mobile; ?>
                  </ul>
              </nav>
          </div>
          <div class="offcanvas-lag-curr mb-6">
              <h2 class="title"><?= __a('glossary'); ?></h2>
              <div class="header-top-lan-curr-link">
                  <div class="header-top-lan dropdown">
                      <button class="dropdown-toggle" data-bs-toggle="dropdown"><?= $glossary_name; ?> <i class="fa fa-angle-down"></i></button>
                      <ul class="dropdown-menu dropdown-menu-right animate slideIndropdown">
                        <?php foreach ($PACMEC['glossary'] as $tag => $info): ?>
                          <li><a class="dropdown-item" href="<?= site_url('/?lang='.$tag); ?>"><?= $info['name']; ?></a></li>
                        <?php endforeach; ?>
                      </ul>
                  </div>

                  <!--//
                  <div class="header-top-curr dropdown">
                      <button class="dropdown-toggle" data-bs-toggle="dropdown">USD <i class="fa fa-angle-down"></i></button>
                      <ul class="dropdown-menu dropdown-menu-right animate slideIndropdown">
                          <li><a class="dropdown-item" href="#">USD</a></li>
                          <li><a class="dropdown-item" href="#">Pound</a></li>
                      </ul>
                  </div>
                  -->
              </div>
          </div>
          <div class="mt-auto">
              <ul class="contact-links">
                  <li><i class="fa fa-phone"></i><a href="#"> <?= infosite('business_phone_number'); ?></a></li>
                  <li><i class="fa fa-envelope-o"></i><a href="#"> <?= infosite('business_phone_number'); ?></a></li>
                  <li><i class="fa fa-clock-o"></i> <span><?= infosite('business_hours'); ?></span> </li>
              </ul>
              <?= do_shortcode('[mt_destry-socials-icons][/mt_destry-socials-icons]'); ?>
          </div>
      </div>
  </div>
  <div class="offcanvas-search">
      <div class="offcanvas-search-inner">
          <div class="offcanvas-btn-close">
              <i class="pe-7s-close"></i>
          </div>
          <form class="offcanvas-search-form" action="#">
              <input type="text" placeholder="Search..." class="offcanvas-search-input">
          </form>
      </div>
  </div>

  <div class="cart-offcanvas-wrapper">
      <div class="offcanvas-overlay"></div>
      <div class="cart-offcanvas-inner">
          <div class="offcanvas-btn-close">
              <i class="pe-7s-close"></i>
          </div>
          <div class="offcanvas-cart-content">
              <h2 class="offcanvas-cart-title mb-10"><?= __a('shopping_cart'); ?></h2>
              <?php
                foreach ($PACMEC['session']->shopping_cart as $key => $item):
                  $url_item = isset($item->data->link_href) ? $item->data->link_href : "#";
                ?>
                <div class="cart-product-wrapper mb-6">
                    <div class="single-cart-product">
                      <div class="cart-product-thumb">
                          <a href="<?= $url_item; ?>">
                            <?php if (isset($item->data->thumb)): ?>
                              <img src="<?= $item->data->thumb; ?>" alt="Cart Product">
                            <?php else: ?>
                              <img src="<?= folder_theme("mt-destry")."/"; ?>assets/images/products/small-product/1.jpg" alt="Cart Product">
                            <?php endif; ?>
                          </a>
                      </div>
                      <div class="cart-product-content">
                          <h3 class="title"><a href="<?= $url_item; ?>"><?= $item->data->name; ?></a></h3>
                          <span class="price">
                            <?php if($item->data->in_promo == true && isset($item->data->price_normal) && isset($item->data->price_promo)): ?>
                              <span class="new"><?= formatMoney($item->data->price); ?></span>
                              <span class="old"><?= formatMoney($item->data->price_normal); ?></span>
                            <?php else: ?>
                              <span class="new"><?= formatMoney($item->data->price); ?></span>
                            <?php endif; ?>
                          </span>
                      </div>
                    </div>
                    <div class="cart-product-remove">
                      x <?= $item->quantity; ?>
                    </div>
                </div>
              <?php endforeach; ?>

              <div class="cart-product-total">
                  <span class="value">Subtotal</span>
                  <span class="price"><?= formatMoney($PACMEC['session']->subtotal_cart); ?></span>
              </div>
              <div class="cart-product-btn mt-4">
                  <a href="<?= __url_S("/%cart_slug%"); ?>" class="btn btn-dark btn-hover-primary rounded-0 w-100"><?= __a('cart_btn'); ?></a>
                  <a href="<?= __url_S("/%checkout_slug%"); ?>" class="btn btn-dark btn-hover-primary rounded-0 w-100 mt-4"><?= __a('checkout_btn'); ?></a>
              </div>
          </div>
      </div>
  </div>
</div>
