<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
?>
<footer class="section footer-section">
    <!-- Footer Top Start -->
    <div class="footer-top section-padding">
        <div class="container">
            <div class="row mb-n10">
                <div class="col-12 col-sm-6 col-lg-4 col-xl-4 mb-10" data-aos="fade-up" data-aos-delay="200">
                    <div class="single-footer-widget">
                        <h2 class="widget-title"><?= __a('contact_us'); ?></h2>
                        <p class="desc-content"><?= infosite('sitedescr'); ?></p>
                        <!-- Contact Address Start -->
                        <ul class="widget-address">
                            <li><span><?= __a('business_address') ?>: </span> <?= infosite('business_address'); ?></li>
                            <li><span><?= __a('business_phone_number') ?>: </span> <a href="#"> <?= infosite('business_phone_number'); ?></a></li>
                            <li><span><?= __a('business_email') ?>: </span> <a href="#"> <?= infosite('business_email'); ?></a></li>
                        </ul>
                        <?= do_shortcode('[mt_destry-socials-icons class="widget-social justify-content-start mt-4"][/mt_destry-socials-icons]'); ?>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-2 col-xl-2 mb-10" data-aos="fade-up" data-aos-delay="300">
                  <?= do_shortcode('[mt_destry-footer-menu title="information" menu_slug="footer_info"][/mt_destry-footer-menu]'); ?>
                </div>
                <div class="col-12 col-sm-6 col-lg-2 col-xl-2 mb-10" data-aos="fade-up" data-aos-delay="400">
                  <?= do_shortcode('[mt_destry-footer-menu title="me_account" menu_slug="footer_me_account"][/mt_destry-footer-menu]'); ?>
                </div>
                <div class="col-12 col-sm-6 col-lg-4 col-xl-4 mb-10" data-aos="fade-up" data-aos-delay="500">
                    <div class="single-footer-widget">
                        <h2 class="widget-title"><?= __a('newsletter'); ?></h2>
                        <div class="widget-body">
                            <p class="desc-content mb-0">Get E-mail updates about our latest shop and special offers.</p>
                            <div class="newsletter-form-wrap pt-4">
                                <form id="mc-form" class="mc-form">
                                    <input type="email" id="mc-email" class="form-control email-box mb-4" placeholder="Enter your email here.." name="EMAIL">
                                    <button id="mc-submit" class="newsletter-btn btn btn-primary btn-hover-dark" type="submit"><?= __a('subscribe'); ?></button>
                                </form>
                                <div class="mailchimp-alerts text-centre">
                                    <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                    <div class="mailchimp-success text-success"></div><!-- mailchimp-success end -->
                                    <div class="mailchimp-error text-danger"></div><!-- mailchimp-error end -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 text-center">
                    <div class="copyright-content">
                        <p class="mb-0"><?= PowBy(); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <?php
              if(MODE_DEBUG == true) require_once PACMEC_PATH . '/.debug/footer.php';
            ?>
        </div>
    </div>
    <!-- Footer Bottom End -->
</footer>
