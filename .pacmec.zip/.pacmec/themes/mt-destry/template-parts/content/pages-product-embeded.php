<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
global $PACMEC;
$PRODUCT = ($PACMEC['route']->product);

?>
<?php if (isset($GLOBALS['PACMEC']['route']->is_embeded) && $GLOBALS['PACMEC']['route']->is_embeded == true): ?>
<div class="section section-margin">
    <div class="container">
      <div class="row">
          <div class="col-md-6 col-12">
              <div class="modal-product-carousel">
                  <div class="swiper-container">
                      <div class="swiper-wrapper">
                        <?php foreach ($PRODUCT->gallery as $picture): ?>
                          <a class="swiper-slide h-auto" href="<?= $picture; ?>">
                              <img class="w-100" src="<?= $picture; ?>" alt="Product">
                          </a>
                        <?php endforeach; ?>
                      </div>
                      <!-- Swiper Pagination Start -->
                      <!-- <div class="swiper-pagination d-md-none"></div> -->
                      <!-- Swiper Pagination End -->
                      <div class="swiper-product-button-next swiper-button-next"><i class="pe-7s-angle-right"></i></div>
                      <div class="swiper-product-button-prev swiper-button-prev"><i class="pe-7s-angle-left"></i></div>
                  </div>
              </div>
          </div>
          <div class="col-md-6 col-12 overflow-hidden position-relative">
              <div class="product-summery">
                  <div class="product-head mb-3">
                      <h2 class="product-title"><?= $PRODUCT->name; ?></h2>
                  </div>
                  <div class="price-box mb-2">
                    <?php if ($PRODUCT->in_promo): ?>
                      <span class="regular-price"><?= $PRODUCT->price_promo; ?></span>
                      <span class="old-price"><del><?= $PRODUCT->price; ?></del></span>
                    <?php else: ?>
                      <span class="regular-price"><?= $PRODUCT->price; ?></span>
                    <?php endif; ?>
                  </div>
                  <span class="ratings justify-content-start">
                    <span class="rating-wrap">
                        <span class="star" style="width: <?= $PRODUCT->rating_porcen; ?>%"></span>
                    </span>
                    <span class="rating-num">(<?= $PRODUCT->rating_number; ?>)</span>
                  </span>
                  <div class="sku mb-3">
                      <span><?=__a('sku_ref');?>: <?= $PRODUCT->sku; ?></span>
                  </div>
                  <?php if (!empty($PRODUCT->common_names)): ?>
                    <div class="sku mb-3">
                      <span><b><?=__a('common_names');?></b> <?= $PRODUCT->common_names; ?></span>
                    </div>
                  <?php endif; ?>
                  <p class="desc-content mb-5">
                      <?= $PRODUCT->description; ?>
                  </p>

                  <?php foreach ($PRODUCT->features as $feature): ?>
                    <?php if ($feature->input_type == 'text' && count($feature->items)>0): ?>
                      <div class="product-meta mb-5">
                          <div class="product-metarial">
                              <span>Metarial :</span>
                              <?php
                                foreach ($feature->items as $item){
                                  echo "<a href=\"#\"><strong>{$item->text}</strong></a>";
                                }
                              ?>
                          </div>
                      </div>
                    <?php endif; ?>
                  <?php endforeach; ?>

                  <?php if ($PRODUCT->available>0): ?>
                    <div class="quantity mb-5">
                      <label><?= ($PRODUCT->unid); ?></label>
                      <div class="cart-plus-minus">
                        <input class="cart-plus-minus-box" value="0" type="text" max="<?= (int) $PRODUCT->available; ?>" step="1" />
                        <div class="dec qtybutton"></div>
                        <div class="inc qtybutton"></div>
                      </div>
                    </div>
                    <div class="cart-wishlist-btn mb-4">
                      <div class="add-to_cart">
                        <a class="btn btn-outline-dark btn-hover-primary" href="#"><?= __a('add_to_cart'); ?></a>
                      </div>
                      <!--// <div class="add-to-wishlist"><a class="btn btn-outline-dark btn-hover-primary" href="wishlist.html">Add to Wishlist</a></div> -->
                    </div>
                  <?php endif; ?>

                  <?= do_shortcode('[mt_destry-social-share][/mt_destry-social-share]'); ?>

                  <ul class="product-delivery-policy border-top pt-4 mt-4 border-bottom pb-4">
                      <li> <i class="fa fa-check-square"></i> <span> <?= __a('total_available_from_site'); ?>: <?= (int) $PRODUCT->available; ?> <?= ($PRODUCT->unid); ?> </span></li>
                      <li><i class="fa fa-truck"></i><span><?= __a('delivery_territory'); ?></span></li>
                      <li><i class="fa fa-usd"></i><span><?= __a('unid_product_view'); ?>: <?= ($PRODUCT->unid); ?></span></li>
                  </ul>
              </div>
            </div>
        </div>
      </div>
  </div>
<?php endif; ?>
