<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
global $PACMEC;
?>
<div class="section">
    <div class="breadcrumb-area bg-light">
        <div class="container-fluid">
            <div class="breadcrumb-content text-center">
                <h1 class="title"><?= __a('cart_title'); ?></h1>
                <ul>
                    <li>
                        <a href="<?= infosite('siteurl').infosite('homeurl'); ?>"><?= __a('home'); ?></a>
                    </li>
                    <li class="active"> <?= __a('shopping_cart'); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="section section-margin">
    <div class="container">
        <div class="row">
            <div class="col-12">
              <form action="" method="POST">
                <div class="cart-table table-responsive">
                  <?= $PACMEC['session']->get_cart_table_html(); ?>
                </div>
                <div class="cart-update-option d-block d-md-flex justify-content-between">
                    <div class="apply-coupon-wrapper">
                        <!--//
                        <form action="#" method="post" class=" d-block d-md-flex">
                            <input type="text" placeholder="Enter Your Coupon Code" required />
                            <button class="btn btn-dark btn-hover-primary rounded-0">Apply Coupon</button>
                        </form>
                        -->
                    </div>
                    <div class="cart-update mt-sm-16">
                      <button type="submit" name="update-cart" class="btn btn-dark btn-hover-primary rounded-0">
                        <?= __a('update_to_cart'); ?>
                      </button>
                    </div>
                </div>
              </form>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-5 ms-auto col-custom">
                <div class="cart-calculator-wrapper">
                    <div class="cart-calculate-items">
                        <h3 class="title">Cart Totals</h3>
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <td><?= __a('subtotal'); ?></td>
                                    <td><?= formatMoney($PACMEC['session']->subtotal_cart); ?></td>
                                </tr>
                              <!--//
                                <tr>
                                    <td><?= __a('shipping'); ?></td>
                                    <td>$70</td>
                                </tr>
                                <tr class="total">
                                    <td>Total</td>
                                    <td class="total-amount">$300</td>
                                </tr>
                              -->
                            </table>
                        </div>
                    </div>
                    <a href="<?= __url_S("/%checkout_slug%"); ?>" class="btn btn-dark btn-hover-primary rounded-0 w-100"><?= __a('checkout_btn'); ?></a>
                </div>
            </div>
        </div>

    </div>
</div>
