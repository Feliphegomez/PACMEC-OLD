<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
 global $PACMEC;
?>

<div class="section section-margin">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="error_form">
                    <h1 class="title">Error</h1>
                    <h2 class="sub-title"><?= __a($PACMEC['route']->title)?></h2>
                    <p><?= $PACMEC['route']->description; ?></p>
                    <form class="search-form-error mb-8" action="#">
                        <input class="input-text" placeholder="Search..." type="text">
                        <button class="submit-btn" type="submit"><i class="fa fa-search"></i></button>
                    </form>
                    <a href="index.html" class="btn btn-primary btn-hover-dark rounded-0">Back to home page</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
echo json_encode($PACMEC['route']);
