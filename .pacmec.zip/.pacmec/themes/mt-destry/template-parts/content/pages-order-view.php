<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
global $PACMEC;
$ORDER = ($PACMEC['route']->order);
?>
<style>
  #invoice{
      padding: 30px;
  }

  .invoice {
      position: relative;
      background-color: #FFF;
      min-height: 680px;
      padding: 15px
  }

  .invoice header {
      padding: 10px 0;
      margin-bottom: 20px;
      border-bottom: 1px solid #3989c6
  }

  .invoice .company-details {
      text-align: right
  }

  .invoice .company-details .name {
      margin-top: 0;
      margin-bottom: 0
  }

  .invoice .contacts {
      margin-bottom: 20px
  }

  .invoice .invoice-to {
      text-align: left
  }

  .invoice .invoice-to .to {
      margin-top: 0;
      margin-bottom: 0
  }

  .invoice .invoice-details {
      text-align: right
  }

  .invoice .invoice-details .invoice-id {
      margin-top: 0;
      color: #3989c6
  }

  .invoice main {
      padding-bottom: 50px
  }

  .invoice main .thanks {
      margin-top: -100px;
      font-size: 2em;
      margin-bottom: 50px
  }

  .invoice main .notices {
      padding-left: 6px;
      border-left: 6px solid #3989c6
  }

  .invoice main .notices .notice {
      font-size: 1.2em
  }

  .invoice table {
      width: 100%;
      border-collapse: collapse;
      border-spacing: 0;
      margin-bottom: 20px
  }

  .invoice table td,.invoice table th {
      padding: 15px;
      background: #eee;
      border-bottom: 1px solid #fff
  }

  .invoice table th {
      white-space: nowrap;
      font-weight: 400;
      font-size: 16px
  }

  .invoice table td h3 {
      margin: 0;
      font-weight: 400;
      color: #3989c6;
      font-size: 1.2em
  }

  .invoice table .qty,.invoice table .total,.invoice table .unit {
      text-align: right;
      font-size: 1.2em
  }

  .invoice table .no {
      color: #fff;
      font-size: 1.6em;
      background: #3989c6
  }

  .invoice table .unit {
      background: #ddd
  }

  .invoice table .total {
      background: #3989c6;
      color: #fff
  }

  .invoice table tbody tr:last-child td {
      border: none
  }

  .invoice table tfoot td {
      background: 0 0;
      border-bottom: none;
      white-space: nowrap;
      text-align: right;
      padding: 10px 20px;
      font-size: 1.2em;
      border-top: 1px solid #aaa
  }

  .invoice table tfoot tr:first-child td {
      border-top: none
  }

  .invoice table tfoot tr:last-child td {
      color: #3989c6;
      font-size: 1.4em;
      border-top: 1px solid #3989c6
  }

  .invoice table tfoot tr td:first-child {
      border: none
  }

  .invoice footer {
      width: 100%;
      text-align: center;
      color: #777;
      border-top: 1px solid #aaa;
      padding: 8px 0
  }

  @media print {
      .invoice {
          font-size: 11px!important;
          overflow: hidden!important
      }

      .invoice footer {
          position: absolute;
          bottom: 10px;
          page-break-after: always
      }

      .invoice>div:last-child {
          page-break-before: always
      }
  }
</style>
<div class="section">
  <div class="breadcrumb-area bg-light">
    <div class="container-fluid">
      <div class="breadcrumb-content text-center">
        <h1 class="title"><?= __a('order_view'); ?></h1>
        <ul>
          <li><a href="<?= \infosite("siteurl"); ?>">Inicio </a></li>
          <li><a href="<?= \__url_s("/%pacmec_meaccount%"); ?>"> <?= __a('me_account'); ?> </a></li>
          <li class="active"> <?= __a('order_view'); ?> </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<div class="section section-margin">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="coupon-accordion">
          <?php if (isGuest()): ?>
            <h3 class="title"><?= __a('signgin_customer_in'); ?> <span id="showlogin"><?= __a('signgin_customer_in_btn'); ?></span></h3>
            <div id="checkout-login" class="coupon-content">
              <div class="coupon-info">
                <!--//<p class="coupon-text mb-2">Quisque gravida turpis sit amet nulla posuere lacinia. Cras sed est sit amet ipsum luctus.</p>-->
                <div class="row">
                  <div class="col-6">
                    <?php
                    $url = urlencode(infosite('siteurl').$PACMEC['path']);
                    echo do_shortcode('[pacmec-form-signin redirect="'.$url.'"][/pacmec-form-signin]');
                    ?>
                  </div>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <?php if ($ORDER->pay_enabled == true): ?>
            <h3 class="title"><?= __a('coupon_prev_txt'); ?> <span id="showcoupon"><?= __a('coupon_click_apply'); ?></span></h3>
            <div id="checkout_coupon" class="coupon-checkout-content">
              <div class="coupon-info">
                <?= do_shortcode("[pacmec-order-apply-coupon order_id=\"{$ORDER->id}\"][/pacmec-order-apply-coupon]"); ?>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <!--//
    <div class="row">
        <div class="col-12">
            <div class="wishlist-table table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="pro-stock"></th>
                            <th class="pro-title"><?= __a('details'); ?></th>
                            <th class="pro-price"><?= __a('price');  ?></th>
                            <th class="pro-price"><?= __a('subtotal');  ?></th>
                            <th class="pro-price"><?= __a('total');  ?></th>
                            <th class="pro-remove"></th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($ORDER->items as $item): ?>
                        <tr>
                          <td class="pro-stock"><span><?= $item->quantity; ?></span></td>
                          <td class="pro-title"><a href="#"><?= $item->name; ?> <span> x <?= $item->unid; ?></span> <br> <?= $item->description; ?></a></td>
                          <td class="pro-stock"></span></td>
                          <td class="pro-price"><span><?= $item->unit_price; ?></span></td>
                          <td class="pro-price">
                            <span>
                              <?php if($item->subtotal>0) echo $item->subtotal; ?>
                              <?php if($item->discounts>0) echo "-{$item->discounts}"; ?>
                            </span>
                          </td>
                          <td class="pro-price"><span><?= $item->total; ?></span></td>
                          <!-- <td class="pro-cart"><a href="cart.html" class="btn btn-dark btn-hover-primary rounded-0">Add to Cart</a></td> --
                          <!-- <td class="pro-remove"><a href="#"><i class="pe-7s-trash"></i></a></td> --
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    -->
    <div class="row mb-n4">
      <div class="col-lg-7 col-12 mb-4">
        <div class="your-order-area ">
          <h3 class="title"><?= __a('order_details'); ?></h3>
          <h5 class="title"><?= "{$ORDER->status}"; ?></h5>
          <div class="your-order-table table-responsive">
            <table class="table">
              <thead>
                <tr class="cart-product-head">
                  <th class="cart-product-name text-start" style="min-width:40%;width:40%;"><?= __a('details'); ?></th>
                  <th class="cart-product-total text-end" style="min-width:25%;width:25%;"><?= __a('price'); ?></th>
                  <th class="cart-product-total text-end" style="min-width:35%;width:35%;"><?= __a('subtotal'); ?></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($ORDER->items as $item): ?>
                  <tr class="cart_item">
                    <td class="cart-product-name text-start ps-0" style="min-width:40%;width:40%;">
                    <?= $item->name; ?>
                    <?php
                      if($item->quantity>0 || !empty($item->unid)){
                        echo "<strong class=\"product-quantity\"> × ";
                        if($item->quantity>0) echo $item->quantity;
                        if (!empty($item->unid)) echo " {$item->unid} ";
                        echo "</strong>";
                      };
                    ?>
                    </td>
                    <td class="cart-product-price text-end pe-0" style="min-width:25%;width:25%;">
                      <?php if($item->subtotal>0) echo "<span class=\"amount\">".formatMoney($item->unit_price)."</span>"; ?>
                    </td>
                    <td class="cart-product-total text-end pe-0" style="min-width:35%;width:35%;">
                      <?php if($item->subtotal>0) echo "<span class=\"amount\">".formatMoney($item->subtotal)."</span>"; ?>
                      <?php if($item->discounts>0) echo "<span class=\"amount\">-".formatMoney($item->discounts)."</span>"; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
              <tfoot>
                <tr class="cart-subtotal">
                  <th style="min-width:100px" class="text-start ps-0"><?= __a('subtotal'); ?></th>
                  <td style="min-width:100px" class="text-end pe-0"><span class="amount"><?= formatMoney($ORDER->subtotal); ?></span></td>
                </tr>
                <tr class="cart-discounts">
                  <th style="min-width:100px" class="text-start ps-0"><?= __a('discounts'); ?></th>
                  <td style="min-width:100px" class="text-end pe-0"><span class="amount"><?= formatMoney($ORDER->discounts); ?></span></td>
                </tr>
                <tr class="order-total">
                  <th style="min-width:100px" class="text-start ps-0"><?= __a('total'); ?></th>
                  <td style="min-width:100px" class="text-end pe-0"><strong><span class="amount"><?= formatMoney($ORDER->total); ?></span></strong></td>
                </tr>
              </tfoot>
            </table>
          </div>
          <br>
          <h3 class="title"><?= __a('payments'); ?></h3>
          <div class="your-order-table table-responsive">
            <table class="table">
              <thead>
                <tr class="cart-product-head">
                  <th class="cart-product-name text-start" style="min-width:40%;width:40%;"><?= __a('details'); ?></th>
                  <th class="cart-product-total text-end" style="min-width:25%;width:25%;"><?= __a('status'); ?></th>
                  <th class="cart-product-total text-end" style="min-width:35%;width:35%;"><?= __a('total_paid'); ?></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($ORDER->payments as $payment): ?>
                  <tr class="cart_item">
                    <td class="cart-product-name text-start ps-0" style="min-width:40%;width:40%;">
                    <?= $payment->tx->transaction_id; ?>

                    <?php
                    echo "<strong class=\"product-quantity\"> ×{$payment->tx->method_pay}</strong>";
                    ?>
                    </td>
                    <td class="cart-product-price text-end pe-0" style="min-width:25%;width:25%;">
                      <span class="amount">
                        <?= $payment->tx->status; ?>
                      </span>
                    </td>
                    <td class="cart-product-total text-end pe-0" style="min-width:35%;width:35%;">
                      <span class="amount">
                        <?= formatMoney($payment->tx->amount_payment); ?>
                      </span>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="col-lg-5 col-12 mb-4">
        <div class="your-order-area border">
          <h3 class="title"><?= __a('your_order'); ?> <?php //"({$ORDER->status})"; ?></h3>
          <div class="your-order-table table-responsive">
            <table class="table">
              <tfoot>
                <tr class="cart-subtotal">
                  <th style="min-width:100px" class="text-start ps-0"><?= __a('total'); ?></th>
                  <td style="min-width:100px" class="text-end pe-0"><span class="amount"><?= formatMoney($ORDER->total); ?></span></td>
                </tr>
                <tr class="cart-discounts">
                  <th style="min-width:100px" class="text-start ps-0"><?= __a('total_paid'); ?></th>
                  <td style="min-width:100px" class="text-end pe-0"><span class="amount"><?= formatMoney($ORDER->payment_total); ?></span></td>
                </tr>
                <tr class="order-total">
                  <th style="min-width:100px" class="text-start ps-0"><?= __a('outstanding_balance'); ?></th>
                  <td style="min-width:100px" class="text-end pe-0"><strong><span class="amount"><?= formatMoney($ORDER->total-$ORDER->payment_total); ?></span></strong></td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div class="payment-accordion-order-button">
            <?php if ($ORDER->pay_enabled == true): ?>
              <div class="order-button-payment">
                <a href="<?= $ORDER->link_pay; ?>" class="btn btn-dark btn-hover-primary rounded-0 w-100"><?= __a('full_payment'); ?></a>
              </div>
              <br>
              <div class="order-button-payment">
                <a data-bs-toggle="collapse" href="#collapseExample-1" aria-expanded="false" aria-controls="collapseExample-1" class="btn btn-dark btn-hover-primary rounded-0 w-100"><?= __a('partial_payment'); ?></a>
              </div>
            <?php endif; ?>
            <br>
            <div class="payment-accordion">
              <div class="single-payment">
                <div class="collapse " id="collapseExample-1">
                  <div class="card card-body rounded-0">
                    <?php
                      $payment_provider = infosite('payment_provider');
                      if(isset($PACMEC['gateways']['payments']->gateways[$payment_provider])){
                        echo $PACMEC['gateways']['payments']->gateways[$payment_provider]->get_form_pay_amount("order_id:{$ORDER->id}");
                      }
                    ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php if (isUser() && $ORDER->isMe()): ?>
            <div class="payment">
              <div class="single-payment">
                <div >
                  <?php
                    foreach ($ORDER->addresses as $address):
                      $address_parts = explode(',', $address->address->full);
                      $address_part1 = $address_parts[0];
                      unset($address_parts[0]);
                      $address_part2 = implode(',', $address_parts);
                    ?>
                    <div class="card card-body rounded-0">
                      <h3 class="title"><?= __a("{$address->type}_address"); ?></h3>
                      <div class="row">
                        <div class="col-md-12 mb-6">
                          <label><?= $address_part1; ?></label>
                          <br><small><?= $address_part2; ?></small>
                        </div>
                        <div class="col-md-12 mb-6">
                          <label>Recibe </label>
                          <br><small><?= "{$ORDER->names} {$ORDER->surname}"; ?> <?php if($ORDER->company_name) echo "({$ORDER->company_name})"; ?> </small>
                          <br><small> <?= "{$ORDER->phone}"; ?> <?= "{$ORDER->mobile}"; ?></small>
                        </div>
                      </div>

                    </div>
                  <?php endforeach; ?>
                </div>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
