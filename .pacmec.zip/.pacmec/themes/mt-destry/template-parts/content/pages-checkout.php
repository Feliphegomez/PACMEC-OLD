<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
global $PACMEC;
?>
<div class="section">
  <div class="breadcrumb-area bg-light">
    <div class="container-fluid">
      <div class="breadcrumb-content text-center">
        <h1 class="title">Checkout</h1>
        <ul>
          <li>
            <a href="index.html">Home </a>
          </li>
          <li class="active"> Checkout</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<div class="section section-margin">
  <div class="container">

      <div class="row">
        <div class="col-12">
          <div class="coupon-accordion">
            <?php if (isGuest()): ?>
              <h3 class="title"><?= __a('signgin_customer_in'); ?> <span id="showlogin"><?= __a('signgin_customer_in_btn'); ?></span></h3>
              <div id="checkout-login" class="coupon-content">
                <div class="coupon-info">
                  <!--//<p class="coupon-text mb-2">Quisque gravida turpis sit amet nulla posuere lacinia. Cras sed est sit amet ipsum luctus.</p>-->
                  <div class="row">
                    <div class="col-6">
                      <?= do_shortcode('[pacmec-form-signin redirect="'.urlencode(infosite('siteurl').$PACMEC['path']).'"][/pacmec-form-signin]'); ?>
                    </div>
                  </div>
                </div>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

    <div class="row mb-n4">
      <div class="col-lg-6 col-12 mb-4">
        <?= do_shortcode('[pacmec-form-create-order-site][/pacmec-form-create-order-site]'); ?>

      </div>
      <div class="col-lg-6 col-12 mb-4">
        <div class="your-order-area border">
          <h3 class="title"><?= __a('your_order'); ?></h3>
          <div class="your-order-table table-responsive">
            <table class="table">
              <thead>
                <tr class="cart-product-head">
                    <th class="cart-product-name text-start">Product</th>
                    <th class="cart-product-total text-end">Total</th>
                </tr>
              </thead>
              <tbody>
                <!--//
                  <tr class="cart_item">
                    <td class="cart-product-name text-start ps-0"> Some Winter Collections<strong class="product-quantity"> × 2</strong></td>
                    <td class="cart-product-total text-end pe-0"><span class="amount">£145.00</span></td>
                  </tr>
                -->
                <?php foreach ($PACMEC['session']->shopping_cart as $key => $item): ?>
                  <tr class="cart_item">
                    <td class="cart-product-name text-start ps-0">
                      <?= $item->data->name; ?><strong class="product-quantity"> × <?= $item->quantity; ?></strong>
                    </td>
                    <td class="cart-product-total text-end pe-0"><span class="amount"><?= formatMoney($item->data->price*$item->quantity); ?></span></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
              <tfoot>
                <tr class="cart-subtotal">
                  <th class="text-start ps-0"><?= __a('subtotal'); ?></th>
                  <td class="text-end pe-0"><span class="amount"><?= formatMoney($PACMEC['session']->subtotal_cart); ?></span></td>
                </tr>
                <!--//
                <tr class="order-total">
                  <th class="text-start ps-0">Order Total</th>
                  <td class="text-end pe-0"><strong><span class="amount">£349.00</span></strong></td>
                </tr>
                -->
              </tfoot>
            </table>
          </div>
          <div class="payment-accordion-order-button">
            <div class="payment-accordion">
              <div class="single-payment">
                <h5 class="panel-title mb-3">
                  <a class="collapse-off" data-bs-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                  <?= __a('shipping_costs_title'); ?>

                  </a>
                </h5>
                <div class="collapse show" id="collapseExample">
                  <div class="card card-body rounded-0">
                    <p><?= __a('shipping_costs_txt'); ?></p>
                  </div>
                </div>
              </div>
              <!--//
              <div class="single-payment">
                <h5 class="panel-title mb-3">
                  <a class="collapse-off" data-bs-toggle="collapse" href="#collapseExample-2" aria-expanded="false" aria-controls="collapseExample-2">
                    Cheque Payment.
                  </a>
                </h5>
                <div class="collapse" id="collapseExample-2">
                  <div class="card card-body rounded-0">
                    <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
                  </div>
                </div>
              </div>
              <div class="single-payment">
                <h5 class="panel-title mb-3">
                  <a class="collapse-off" data-bs-toggle="collapse" href="#collapseExample-3" aria-expanded="false" aria-controls="collapseExample-3">
                    Paypal.
                  </a>
                </h5>
                <div class="collapse" id="collapseExample-3">
                  <div class="card card-body rounded-0">
                    <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
                  </div>
                </div>
              </div>
              -->
            </div>
            <!--//
            <div class="order-button-payment">
              <button class="btn btn-dark btn-hover-primary rounded-0 w-100"><?= __a('place_order'); ?></button>
            </div>
          -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
