<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */
 global $PACMEC;
?>

<div class="section section-margin">
    <div class="container">
        <div class="row mb-n10">
            <div class="col-lg-12 col-md-12 m-auto m-lg-0 pb-10">
                <!-- Login Wrapper Start -->
                <div class="login-wrapper">

                    <!-- Login Title & Content Start -->
                    <div class="section-content text-center mb-5">
                        <h2 class="title mb-2"><?= __a('pacmec_forgotten_password'); ?></h2>
                        <p class="desc-content"><?= __a('pacmec_forgotten_password_txt'); ?></p>
                    </div>
                      <h2 class="title mb-2"></h2>
                      <?= do_shortcode('[pacmec-form-forgotten-password][/pacmec-form-forgotten-password]'); ?>
                </div>
            </div>
        </div>

    </div>
</div>
