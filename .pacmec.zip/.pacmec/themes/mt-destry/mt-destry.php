<?php
/**
 * Theme Name: Distry Manager Technology
 * Theme URI: https://github.com/ManagerTechnologyCO/PACMEC-Theme-MT-Distry
 * Description: Sin description
 * Version: 0.1
 * Author: FelipheGomez
 * Author URI: https://github.com/FelipheGomez
 * Text Domain: mt-destry
 * Copyright 2020-2021
 * (email : feliphegomez@gmail.com)
 * GPLv2 Full license details in license.txt
 */
function pacmec_Theme_MT_Distry_activation()
{
  try {
    require_once 'includes/shortcodes.php';
    /** HEAD **/
    // Use the minified version files listed below for better performance and remove the files listed above
    add_style_head(folder_theme("mt-destry")."/assets/css/vendor.min.css", ["rel"=>"stylesheet", "type"=>"text/css", "charset"=>"UTF-8"], 0.3, true);
    add_style_head(folder_theme("mt-destry")."/assets/css/plugins.min.css", ["rel"=>"stylesheet", "type"=>"text/css", "charset"=>"UTF-8"], 0.3, true);
    add_style_head(folder_theme("mt-destry")."/assets/css/style.min.css", ["rel"=>"stylesheet", "type"=>"text/css", "charset"=>"UTF-8"], 0.3, true);

    /** FOOTER **/
    // Use the minified version files listed below for better performance and remove the files listed above
    add_scripts_foot(folder_theme("mt-destry")."/assets/js/vendor.min.js", ["type"=>"text/javascript", "charset"=>"UTF-8"], 0.3, true);
    add_scripts_foot(folder_theme("mt-destry")."/assets/js/plugins.min.js", ["type"=>"text/javascript", "charset"=>"UTF-8"], 0.3, true);
    // Main JS
    add_scripts_foot(folder_theme("mt-destry")."/assets/js/main.js", ["type"=>"text/javascript", "charset"=>"UTF-8"], 0.3, true);

    $tbls = [];
    foreach ($tbls as $tbl) {
      if(!pacmec_tbl_exist($tbl)){
        throw new \Exception("Falta la tbl: {$tbl}", 1);
      }
    }
  } catch (\Exception $e) {
    echo $e->getMessage();
    exit;
  }
}
\register_activation_plugin('mt-destry', 'pacmec_Theme_MT_Distry_activation');
