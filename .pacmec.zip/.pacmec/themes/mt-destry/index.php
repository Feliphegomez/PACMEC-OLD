<?php
/**
 *
 * @author     FelipheGomez <feliphegomez@gmail.com>
 * @package    Themes
 * @category   Destry Manager Technology CO
 * @version    0.1
 */

pacmec_add_meta_tag('fb:app_id', "278430430061430");
?>
<!DOCTYPE html>
<html <?= language_attributes(); ?>>
  <head>
    <meta charset="<?= pageinfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php \pacmec_head(); ?>
    <style>
      .frame-box-modal {
        width: 100%;
        height: calc(60vh);
      }
    </style>
  </head>
  <body>
		<script>
			window.fbAsyncInit = function() {
				FB.init({
					appId            : '278430430061430',
					autoLogAppEvents : true,
					xfbml            : true,
					version          : 'v7.0'
				});
			};
			shareOnFB = function () {
				var desc = "@ViewBag.description";
				var title = document.title;
				var link = location.href;
				var image = "@ViewBag.Image";

				FB.ui({
					method: 'share_open_graph',
					action_type: 'og.shares',
					action_properties: JSON.stringify({
						object: {
							'og:url': link,
							'og:title': title,
							'og:description': desc,
							'og:Image': image,
							'og:image:width': 540,
							'og:image:height': 281
						}
					})
				}),
				function (response) {
					console.log(response);
				};
			};
		</script>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_LA/sdk.js"></script>
    <?= "<div id=\"pacmec_sv_us_begin\"></div>"; ?>
    <?php
      if(!isset($GLOBALS['PACMEC']['route']->is_embeded) || $GLOBALS['PACMEC']['route']->is_embeded !== true){
        \get_template_part('template-parts/header/site-header');
      }
    ?>
      <?php
        // get_template_part('template-parts/content/test');
        if(\route_active())
        { \get_template_part( 'template-parts/content/'.$GLOBALS['PACMEC']['route']->layout ); }
        else
        { \get_template_part( 'template-parts/content/content-error' ); }
      ?>
    <?php
    echo "<div id=\"pacmec_sv_us_end\"></div>";
    ?>

    <?php get_footer(); ?>
