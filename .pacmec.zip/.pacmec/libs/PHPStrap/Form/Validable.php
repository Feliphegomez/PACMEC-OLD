<?php

namespace PHPStrap\Form;

interface Validable {

	public function isValid();

}
?>
